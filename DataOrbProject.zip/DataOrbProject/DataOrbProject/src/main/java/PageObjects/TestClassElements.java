package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import dev.failsafe.internal.util.Assert;
import net.bytebuddy.implementation.bind.annotation.Super;

public class TestClassElements extends Basepage{
	
	
	
	public TestClassElements() {
		
		PageFactory.initElements(driver, this);
	}
	
	
	//pageFactory
	@FindBy(xpath="//*[@class='_2KpZ6l _2doB4z']")
	WebElement closeButton;
	
	@FindBy(xpath="//*[@class='_1ve3GO']/a")
	WebElement banner;
	
	@FindBy(xpath="(//*[@class='RWB9Wm'])[1]")
	WebElement electronicsTab;
	
	@FindBy(xpath="//*[@class='_1fwVde']/a")
	List<WebElement> listOfElectronics;
	
	public void getList() {
		JavascriptExecutor js = (JavascriptExecutor)driver;
				
		closeButton.click();
		js.executeScript("arguments[0].click();", banner);
		Actions act=new Actions(driver);
		act.moveToElement(electronicsTab).perform();
		
		int size=listOfElectronics.size();
		
		System.out.println("Size: "+size);
		for(int i=0;i<size;i++)
		{
			System.out.println(listOfElectronics.get(i).getText());
		}
		System.out.println("Size: "+size);
		//org.testng.Assert.assertEquals(true, true);
	}
	
}
