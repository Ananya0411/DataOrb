package Projects.DataOrbProject;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import PageObjects.Basepage;
import PageObjects.TestClassElements;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestClass extends Basepage {
	@Test
	public void getList()
	{
		TestClassElements tc = new TestClassElements();
		tc.getList();
	}
}
	
	
	

